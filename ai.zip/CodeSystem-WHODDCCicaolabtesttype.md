# ICAO lab test type codes used in this IG - WHO Digital Documentation of COVID-19 Certificates (DDCC) v1.0.0

* [**Table of Contents**](toc.md)
* [**Artifacts Summary**](artifacts.md)
* **ICAO lab test type codes used in this IG**

## CodeSystem: ICAO lab test type codes used in this IG (Experimental) 

| | |
| :--- | :--- |
| *Official URL*:http://smart.who.int/ddcc/CodeSystem/WHODDCCicaolabtesttype | *Version*:1.0.0 |
| Draft as of 2026-11-19 | *Computable Name*:WHODDCCicaolabtesttype |

 
All ICAO lab test type codes from its internally defined code system used in this IG. Provided so the FHIR server can perform expansions. 

 This Code system is referenced in the content logical definition of the following value sets: 

* This CodeSystem is not used here; it may be used elsewhere (e.g. specifications and/or implementations that use this content)



## Resource Content

```json
{
  "resourceType" : "CodeSystem",
  "id" : "WHODDCCicaolabtesttype",
  "url" : "http://smart.who.int/ddcc/CodeSystem/WHODDCCicaolabtesttype",
  "version" : "1.0.0",
  "name" : "WHODDCCicaolabtesttype",
  "title" : "ICAO lab test type codes used in this IG",
  "status" : "draft",
  "experimental" : true,
  "date" : "2026-11-19T08:03:03+00:00",
  "publisher" : "WHO",
  "contact" : [{
    "name" : "WHO",
    "telecom" : [{
      "system" : "url",
      "value" : "http://who.int"
    }]
  }],
  "description" : "All ICAO lab test type codes from its internally defined code system used in this IG. Provided so the FHIR server can perform expansions.",
  "jurisdiction" : [{
    "coding" : [{
      "system" : "http://unstats.un.org/unsd/methods/m49/m49.htm",
      "code" : "001"
    }]
  }],
  "caseSensitive" : true,
  "content" : "complete",
  "count" : 4,
  "concept" : [{
    "code" : "molecular(PCR)",
    "display" : "Molecular (PCR)"
  },
  {
    "code" : "molecular(other)",
    "display" : "Molecular (Other)"
  },
  {
    "code" : "antigen",
    "display" : "Antigen"
  },
  {
    "code" : "antibody",
    "display" : "Antibody"
  }]
}

```
